-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema annexfactura
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema annexfactura
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `annexfactura` DEFAULT CHARACTER SET utf8 ;
USE `annexfactura` ;

-- -----------------------------------------------------
-- Table `annexfactura`.`provincias`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `annexfactura`.`provincias` (
  `CodProvincia` INT(11) NOT NULL AUTO_INCREMENT,
  `Provincia` VARCHAR(250) CHARACTER SET 'latin1' COLLATE 'latin1_spanish_ci' NOT NULL,
  PRIMARY KEY (`CodProvincia`),
  UNIQUE INDEX `Codprovincia` (`CodProvincia` ASC))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1
COLLATE = latin1_spanish_ci;


-- -----------------------------------------------------
-- Table `annexfactura`.`cliente`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `annexfactura`.`cliente` (
  `CodCliente` INT(11) NOT NULL AUTO_INCREMENT,
  `Dni` VARCHAR(9) NULL,
  `Nombre` VARCHAR(150) CHARACTER SET 'latin1' COLLATE 'latin1_spanish_ci' NOT NULL,
  `Apellido1` VARCHAR(150) CHARACTER SET 'latin1' COLLATE 'latin1_spanish_ci' NOT NULL,
  `Apellido2` VARCHAR(150) CHARACTER SET 'latin1' COLLATE 'latin1_spanish_ci' NOT NULL,
  `Direccion` VARCHAR(250) CHARACTER SET 'latin1' COLLATE 'latin1_spanish_ci' NOT NULL,
  `CodigoPostal` INT(11) NOT NULL,
  `Municipio` VARCHAR(200) CHARACTER SET 'latin1' COLLATE 'latin1_spanish_ci' NOT NULL,
  `CodProvincia` INT(11) NOT NULL,
  `Telefono` INT(11) NOT NULL,
  `Email` VARCHAR(200) CHARACTER SET 'latin1' COLLATE 'latin1_spanish_ci' NOT NULL,
  `Estado` INT(11) NOT NULL,
  PRIMARY KEY (`CodCliente`),
  INDEX `CodProvincia` (`CodProvincia` ASC),
  CONSTRAINT `cliente_ibfk_1`
    FOREIGN KEY (`CodProvincia`)
    REFERENCES `annexfactura`.`provincias` (`CodProvincia`)
    ON UPDATE CASCADE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1
COLLATE = latin1_spanish_ci;


-- -----------------------------------------------------
-- Table `annexfactura`.`albaran`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `annexfactura`.`albaran` (
  `CodAlbaran` VARCHAR(12) CHARACTER SET 'latin1' COLLATE 'latin1_spanish_ci' NOT NULL,
  `CodCliente` INT(11) NOT NULL,
  `Fecha` DATE NOT NULL,
  `CodFactura` INT(11) NOT NULL,
  INDEX `CodFactura` (`CodFactura` ASC),
  INDEX `CodCliente` (`CodCliente` ASC),
  INDEX `CodAlbaran` (`CodAlbaran` ASC),
  INDEX `CodAlbaran_2` (`CodAlbaran` ASC),
  INDEX `CodFactura_2` (`CodFactura` ASC),
  PRIMARY KEY (`CodAlbaran`),
  CONSTRAINT `cliente albaran`
    FOREIGN KEY (`CodCliente`)
    REFERENCES `annexfactura`.`cliente` (`CodCliente`)
    ON DELETE NO ACTION
    ON UPDATE RESTRICT)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1
COLLATE = latin1_spanish_ci;


-- -----------------------------------------------------
-- Table `annexfactura`.`factura`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `annexfactura`.`factura` (
  `CodCliente` INT(11) NOT NULL,
  `Fecha` INT(11) NOT NULL,
  `Observaciones` TEXT CHARACTER SET 'latin1' COLLATE 'latin1_spanish_ci' NOT NULL,
  `Estado` VARCHAR(1) CHARACTER SET 'latin1' COLLATE 'latin1_spanish_ci' NOT NULL,
  `CodFactura` VARCHAR(12) CHARACTER SET 'latin1' COLLATE 'latin1_spanish_ci' NOT NULL,
  INDEX `CodCliente` (`CodCliente` ASC),
  PRIMARY KEY (`CodFactura`),
  CONSTRAINT `cliente`
    FOREIGN KEY (`CodCliente`)
    REFERENCES `annexfactura`.`cliente` (`CodCliente`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1
COLLATE = latin1_spanish_ci;


-- -----------------------------------------------------
-- Table `annexfactura`.`detalle`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `annexfactura`.`detalle` (
  `CodFactura` VARCHAR(12) CHARACTER SET 'latin1' NOT NULL,
  `CodAlbaran` VARCHAR(12) CHARACTER SET 'latin1' NOT NULL,
  `Concepto` VARCHAR(1000) CHARACTER SET 'latin1' NOT NULL,
  `Cantidad` INT(11) NOT NULL,
  `ImporteUnitario` INT(11) NOT NULL,
  `CodIva` INT(11) NOT NULL,
  `Descuento` INT(11) NOT NULL,
  `Estado` VARCHAR(1) CHARACTER SET 'latin1' NOT NULL,
  `numdetalle` DOUBLE NOT NULL,
  `factura_CodFactura` VARCHAR(12) CHARACTER SET 'latin1' COLLATE 'latin1_spanish_ci' NOT NULL,
  `albaran_CodAlbaran` VARCHAR(12) CHARACTER SET 'latin1' COLLATE 'latin1_spanish_ci' NOT NULL,
  INDEX `CodIva` (`CodIva` ASC),
  PRIMARY KEY (`numdetalle`),
  INDEX `fk_detalle_factura1_idx` (`factura_CodFactura` ASC),
  INDEX `fk_detalle_albaran1_idx` (`albaran_CodAlbaran` ASC),
  CONSTRAINT `fk_detalle_factura1`
    FOREIGN KEY (`factura_CodFactura`)
    REFERENCES `annexfactura`.`factura` (`CodFactura`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_detalle_albaran1`
    FOREIGN KEY (`albaran_CodAlbaran`)
    REFERENCES `annexfactura`.`albaran` (`CodAlbaran`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1
COLLATE = latin1_spanish_ci;


-- -----------------------------------------------------
-- Table `annexfactura`.`impuesto`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `annexfactura`.`impuesto` (
  `CodIva` INT(11) NOT NULL AUTO_INCREMENT,
  `ValorIva` INT(11) NOT NULL,
  `Descripcion` VARCHAR(150) CHARACTER SET 'latin1' COLLATE 'latin1_spanish_ci' NOT NULL,
  PRIMARY KEY (`CodIva`),
  INDEX `CodIva` (`CodIva` ASC))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1
COLLATE = latin1_spanish_ci;


-- -----------------------------------------------------
-- Table `annexfactura`.`Conceptos`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `annexfactura`.`Conceptos` (
  `CodConcepto` INT NOT NULL,
  `Descripcion` VARCHAR(300) NOT NULL,
  `Importe` DOUBLE NOT NULL,
  `Descuento` INT NULL,
  `CodIva` INT NOT NULL,
  `Estado` VARCHAR(1) NOT NULL,
  PRIMARY KEY (`CodConcepto`),
  INDEX `Impuesto_idx` (`CodIva` ASC),
  INDEX `Concepto` (`Descripcion` ASC),
  CONSTRAINT `Impuesto`
    FOREIGN KEY (`CodIva`)
    REFERENCES `annexfactura`.`impuesto` (`CodIva`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `annexfactura`.`Usuarios`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `annexfactura`.`Usuarios` (
  `Usuario` VARCHAR(50) NOT NULL,
  `Paswword` VARCHAR(50) NOT NULL,
  `Estado` VARCHAR(1) NULL,
  PRIMARY KEY (`Usuario`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `annexfactura`.`conceptos`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `annexfactura`.`conceptos` (
  `CodConcepto` INT(11) NOT NULL,
  `Descripcion` VARCHAR(300) NOT NULL,
  `Importe` DOUBLE NOT NULL,
  `Descuento` INT(11) NULL DEFAULT NULL,
  `CodIva` INT(11) NOT NULL,
  `Estado` VARCHAR(1) NOT NULL,
  PRIMARY KEY (`CodConcepto`),
  INDEX `Impuesto_idx` (`CodIva` ASC),
  INDEX `Concepto` (`Descripcion` ASC),
  CONSTRAINT `Impuesto`
    FOREIGN KEY (`CodIva`)
    REFERENCES `annexfactura`.`impuesto` (`CodIva`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `annexfactura`.`presupuesto`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `annexfactura`.`presupuesto` (
  `CodPresupuesto` VARCHAR(12) CHARACTER SET 'latin1' COLLATE 'latin1_spanish_ci' NOT NULL,
  `CodCliente` INT(11) NOT NULL,
  `Fecha` DATE NOT NULL,
  `CodFactura` INT(11) NULL DEFAULT NULL,
  `Estado` VARCHAR(1) CHARACTER SET 'latin1' COLLATE 'latin1_spanish_ci' NOT NULL,
  PRIMARY KEY (`CodPresupuesto`),
  INDEX `CodFactura` (`CodFactura` ASC),
  INDEX `CodCliente` (`CodCliente` ASC),
  INDEX `CodAlbaran` (`CodPresupuesto` ASC),
  INDEX `CodAlbaran_2` (`CodPresupuesto` ASC),
  INDEX `CodFactura_2` (`CodFactura` ASC),
  CONSTRAINT `Clliente`
    FOREIGN KEY (`CodCliente`)
    REFERENCES `annexfactura`.`cliente` (`CodCliente`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `Factura`
    FOREIGN KEY (`CodFactura`)
    REFERENCES `annexfactura`.`factura` (`CodCliente`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `Presupuesto`
    FOREIGN KEY (`CodPresupuesto`)
    REFERENCES `annexfactura`.`presupuesto` (`CodPresupuesto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1
COLLATE = latin1_spanish_ci;


-- -----------------------------------------------------
-- Table `annexfactura`.`usuarios`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `annexfactura`.`usuarios` (
  `Usuario` VARCHAR(50) NOT NULL,
  `Paswword` VARCHAR(50) NOT NULL,
  `Estado` VARCHAR(1) NULL DEFAULT NULL,
  PRIMARY KEY (`Usuario`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
